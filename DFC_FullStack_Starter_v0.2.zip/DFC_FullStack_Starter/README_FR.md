# DFC — Désiré FreeChat
**Slogan : « La liberté de communiquer. »**

Ce dossier est une base de développement réelle, pas une application de production déjà publiée. Il contient :
- une copie du prototype web actuel dans `public/index.html` ;
- une API Node.js/Express ;
- une base SQLite créée automatiquement ;
- comptes, connexion par JWT et mots de passe hachés avec bcrypt ;
- recherche d'utilisateurs et demandes d'amis ;
- conversations privées/groupes, messages REST et événements temps réel Socket.IO ;
- publications, médias téléversés, likes et commentaires ;
- notifications en base, notifications temps réel et point d'intégration Web Push ;
- signalisation d'appels audio/vidéo WebRTC ;
- historique des appels.

## Démarrage sur un ordinateur ou un hébergement Node.js
1. Installer Node.js 20 ou plus récent.
2. Dans ce dossier, copier `.env.example` vers `.env`.
3. Modifier `JWT_SECRET` par une longue valeur aléatoire privée. Pour une vraie mise en ligne, définir aussi `CORS_ORIGIN` et `PUBLIC_BASE_URL` avec le domaine HTTPS.
4. Exécuter `npm install`, puis `npm start`.
5. Ouvrir `http://localhost:3000/api/health` pour vérifier l'API et `http://localhost:3000` pour l'interface actuelle.

## Tests rapides de l'API
Créer un compte :
```sh
curl -X POST http://localhost:3000/api/auth/register -H 'Content-Type: application/json' -d '{"username":"demo1","password":"motdepasse123","displayName":"Démo 1"}'
```
Utiliser le `token` reçu comme en-tête `Authorization: Bearer TOKEN` sur les routes protégées.

## Important — travail encore nécessaire
- **L'interface existante n'est pas encore raccordée à ces routes** : il faut remplacer les données de démonstration par des appels API et gérer le token côté client de façon sûre.
- Les appels WebRTC ont le relais de signalisation côté serveur, mais le client doit encore gérer `getUserMedia`, `RTCPeerConnection`, les écrans d'appel et la configuration STUN/TURN. Pour fonctionner sur différents réseaux, un serveur TURN est souvent nécessaire.
- Web Push exige HTTPS, une clé VAPID et un Service Worker avec code d'abonnement/affichage des notifications.
- Les messages sont enregistrés en clair dans SQLite pour cette version de départ : le chiffrement de bout en bout n'est pas implémenté.
- Le mode Wi‑Fi Direct/Bluetooth exige une vraie application Android native et une stratégie de découverte/transport ; une page HTML ne peut pas offrir les permissions et l'accès système requis. Voir `android-native-notes/README_FR.md`.
- Avant la production : HTTPS, limitation des tentatives de connexion, validation renforcée, sauvegardes, suppression/export des données, rôles admin, modération, tests et surveillance.

## API principale
- `POST /api/auth/register`, `POST /api/auth/login`, `GET/PATCH /api/me`
- `GET /api/users/search?q=...`, `POST /api/friends/request`, `GET /api/friends`, `POST /api/friends/:id/accept`
- `POST/GET /api/conversations`, `GET/POST /api/conversations/:id/messages`
- Socket.IO : `conversation:join`, `message:new`, `typing`
- `POST /api/uploads`, `GET/POST /api/posts`, `POST /api/posts/:id/like`, `GET/POST /api/posts/:id/comments`
- `GET /api/notifications`, `POST /api/notifications/:id/read`, `POST /api/push/subscribe`
- `POST /api/calls`, `POST /api/calls/:id/end`, `GET /api/calls/history`
- Socket.IO : `call:offer`, `call:answer`, `call:ice`, `call:reject`, `call:end`

## Page de test de l'API
Après démarrage, ouvrir `/backend.html`. Elle permet de créer deux comptes de test, rechercher des utilisateurs, envoyer des demandes d'amis, ouvrir une conversation et tester les messages temps réel, les publications et notifications. Elle n'est pas encore l'interface finale et les boutons d'appel testent seulement la signalisation.

## PWA
Le manifeste et le service worker sont fournis pour le shell web. L'installation PWA exige un site HTTPS (localhost convient en développement). Les données API et les événements temps réel ne sont pas disponibles hors ligne sans une couche de synchronisation spécifique.


## Mise à jour du projet — version 0.2.0
Cette version ajoute une première implémentation WebRTC dans `public/backend.html` : accès au micro/caméra, offres/réponses, candidats ICE, acceptation/refus et raccrochage. Le service worker affiche les notifications push reçues, et l'écran de test peut demander l'abonnement push si le serveur possède ses clés VAPID. La page principale renvoie explicitement vers cet espace de test connecté tout en précisant qu'elle conserve encore ses données localement.

Un premier fichier Kotlin `android-native-notes/NearbyTransport.kt` fournit un point de départ pour transporter des messages via Wi-Fi Direct ou Bluetooth RFCOMM. Il n'est pas encore intégré à une application Android complète, il n'a pas été compilé dans ce contexte et les données transportées ne sont pas chiffrées par cette classe : ne l'utilise pas pour des données privées avant intégration d'un protocole de chiffrement et des tests de sécurité.

## Contrôle de syntaxe
Après extraction du ZIP, lance `npm run check`. Cela vérifie la syntaxe JavaScript du serveur, du service worker et des scripts des pages HTML. Cela ne prouve pas que le serveur fonctionne : pour cela, il faut installer les dépendances, démarrer le serveur et tester avec deux comptes et deux appareils.

## Notifications push réelles
1. Sur une machine de développement ou un serveur Node.js, installe les dépendances avec `npm install`.
2. Génère une paire de clés VAPID avec `npx web-push generate-vapid-keys`.
3. Copie les clés publique et privée dans `.env`, puis renseigne un `VAPID_SUBJECT` valide.
4. Déploie sur HTTPS, redémarre le serveur, connecte un compte et appuie sur « Activer les notifications » dans `/backend.html`.

## État honnête de cette version
Le serveur et la base n'ont pas été démarrés dans cet environnement : l'installation des dépendances a expiré ici. Les contrôles syntaxiques passent, mais les tests de fonctionnement, les appels entre deux réseaux, les notifications push, la compilation Android et les communications Wi-Fi Direct/Bluetooth doivent encore être réalisés. Le mode de communication local Android est un socle natif à intégrer, pas une fonction finale déjà disponible dans l'interface principale.
