const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const files = ['server.js', 'public/sw.js'];
function check(file, source) {
  const tmp = path.join(require('node:os').tmpdir(), `dfc-check-${process.pid}-${Math.random().toString(16).slice(2)}.js`);
  fs.writeFileSync(tmp, source);
  const result = spawnSync(process.execPath, ['--check', tmp], { encoding: 'utf8' });
  fs.rmSync(tmp, { force: true });
  if (result.status !== 0) {
    process.stderr.write(`${file}:\n${result.stderr || result.stdout}`);
    process.exitCode = 1;
  } else console.log(`OK syntaxe : ${file}`);
}
for (const file of files) check(file, fs.readFileSync(path.join(root, file), 'utf8'));
for (const file of ['public/index.html', 'public/backend.html']) {
  const html = fs.readFileSync(path.join(root, file), 'utf8');
  const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(Boolean);
  check(`${file} (scripts intégrés)`, scripts.join('\n'));
}
if (!process.exitCode) console.log('Contrôle syntaxique terminé. Cela ne remplace pas les tests de fonctionnement avec le serveur lancé.');
