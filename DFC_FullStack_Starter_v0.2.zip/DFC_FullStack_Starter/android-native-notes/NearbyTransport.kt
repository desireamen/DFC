package com.dfc.nearby

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.Executors

/**
 * DFC native nearby-transport starter.
 * Android UI must request runtime permissions before calling these methods.
 * This class transports UTF-8 payloads; the caller must encrypt/authenticate them before production.
 */
class NearbyTransport(context: Context, private val listener: Listener) {
    interface Listener {
        fun onStatus(message: String)
        fun onPeerList(peers: List<WifiP2pDevice>) {}
        fun onMessage(payload: String)
        fun onConnected(transport: String)
    }

    private val appContext = context.applicationContext
    private val worker = Executors.newCachedThreadPool()
    private val wifiManager = appContext.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val channel = wifiManager.initialize(appContext, appContext.mainLooper, null)
    private var socket: Socket? = null
    private var output: DataOutputStream? = null
    private var serverSocket: ServerSocket? = null
    private var bluetoothServer: BluetoothServerSocket? = null
    private var registered = false
    private var transportName = "local"

    private val p2pReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    @SuppressLint("MissingPermission")
                    wifiManager.requestPeers(channel) { list ->
                        listener.onStatus("Appareils Wi-Fi Direct détectés : ${list.deviceList.size}.")
                        listener.onPeerList(list.deviceList.toList())
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    @Suppress("DEPRECATION")
                    val info = if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_INFO, WifiP2pInfo::class.java)
                    } else intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_INFO) as? WifiP2pInfo
                    if (info?.groupFormed == true) {
                        if (info.isGroupOwner) startWifiServer() else connectWifiSocket(info.groupOwnerAddress.hostAddress ?: return)
                    }
                }
            }
        }
    }

    fun register() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            appContext.registerReceiver(p2pReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            appContext.registerReceiver(p2pReceiver, filter)
        }
        registered = true
    }

    @SuppressLint("MissingPermission")
    fun discoverWifiDirect() {
        try {
            wifiManager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = listener.onStatus("Recherche Wi-Fi Direct démarrée.")
                override fun onFailure(reason: Int) = listener.onStatus("Échec Wi-Fi Direct (code $reason). Vérifie les autorisations et le Wi-Fi.")
            })
        } catch (e: SecurityException) { listener.onStatus("Autorisation Wi-Fi Direct manquante : ${e.message}") }
    }

    @SuppressLint("MissingPermission")
    fun connectWifiDirect(deviceAddress: String) {
        val config = WifiP2pConfig().apply { this.deviceAddress = deviceAddress }
        try {
            wifiManager.connect(channel, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = listener.onStatus("Demande de connexion Wi-Fi Direct envoyée.")
                override fun onFailure(reason: Int) = listener.onStatus("Connexion Wi-Fi Direct refusée (code $reason).")
            })
        } catch (e: SecurityException) { listener.onStatus("Autorisation Wi-Fi Direct manquante : ${e.message}") }
    }

    private fun startWifiServer() = worker.execute {
        try {
            closeSocketOnly()
            serverSocket?.close()
            serverSocket = ServerSocket(PORT).also { listener.onStatus("DFC attend un pair Wi-Fi Direct sur le port $PORT.") }
            val accepted = serverSocket!!.accept()
            attachSocket(accepted, "Wi-Fi Direct")
        } catch (e: IOException) { listener.onStatus("Serveur Wi-Fi Direct : ${e.message}") }
    }

    private fun connectWifiSocket(host: String) = worker.execute {
        try {
            closeSocketOnly()
            val candidate = Socket()
            candidate.connect(InetSocketAddress(host, PORT), 12_000)
            attachSocket(candidate, "Wi-Fi Direct")
        } catch (e: IOException) { listener.onStatus("Connexion Wi-Fi Direct impossible : ${e.message}") }
    }

    @SuppressLint("MissingPermission")
    fun startBluetoothServer(adapter: BluetoothAdapter) = worker.execute {
        try {
            bluetoothServer?.close()
            bluetoothServer = adapter.listenUsingRfcommWithServiceRecord("DFC", SERVICE_UUID)
            listener.onStatus("DFC attend une connexion Bluetooth.")
            attachSocket(bluetoothServer!!.accept(), "Bluetooth")
        } catch (e: SecurityException) { listener.onStatus("Autorisation Bluetooth manquante : ${e.message}") }
        catch (e: IOException) { listener.onStatus("Serveur Bluetooth : ${e.message}") }
    }

    @SuppressLint("MissingPermission")
    fun connectBluetooth(device: BluetoothDevice) = worker.execute {
        try {
            closeSocketOnly()
            val candidate = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
            candidate.connect()
            attachSocket(candidate, "Bluetooth")
        } catch (e: SecurityException) { listener.onStatus("Autorisation Bluetooth manquante : ${e.message}") }
        catch (e: IOException) { listener.onStatus("Connexion Bluetooth impossible : ${e.message}") }
    }

    @Synchronized
    private fun attachSocket(candidate: Socket, label: String) {
        closeSocketOnly()
        socket = candidate
        transportName = label
        val input = DataInputStream(BufferedInputStream(candidate.getInputStream()))
        output = DataOutputStream(BufferedOutputStream(candidate.getOutputStream()))
        listener.onConnected(label)
        listener.onStatus("Connexion locale $label établie.")
        worker.execute {
            try {
                while (!candidate.isClosed) {
                    val size = input.readInt()
                    if (size !in 1..MAX_PACKET) throw IOException("Taille de message non valide")
                    val bytes = ByteArray(size)
                    input.readFully(bytes)
                    listener.onMessage(bytes.toString(Charsets.UTF_8))
                }
            } catch (e: IOException) { listener.onStatus("Connexion $label terminée : ${e.message}") }
        }
    }

    @Synchronized
    fun send(payload: String) {
        val bytes = payload.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty() || bytes.size > MAX_PACKET) throw IllegalArgumentException("Message trop grand ou vide")
        val out = output ?: throw IllegalStateException("Aucun appareil connecté")
        worker.execute {
            try { synchronized(out) { out.writeInt(bytes.size); out.write(bytes); out.flush() } }
            catch (e: IOException) { listener.onStatus("Échec d'envoi : ${e.message}") }
        }
    }

    @Synchronized
    private fun closeSocketOnly() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
        output = null
    }

    fun close() {
        closeSocketOnly()
        try { serverSocket?.close() } catch (_: IOException) {}
        try { bluetoothServer?.close() } catch (_: IOException) {}
        serverSocket = null
        bluetoothServer = null
        if (registered) { try { appContext.unregisterReceiver(p2pReceiver) } catch (_: IllegalArgumentException) {}; registered = false }
        worker.shutdownNow()
    }

    companion object {
        private const val PORT = 38473
        private const val MAX_PACKET = 1024 * 1024
        private val SERVICE_UUID: UUID = UUID.fromString("c9e1f9f2-0a1e-4f75-9c4a-444643303031")
    }
}
