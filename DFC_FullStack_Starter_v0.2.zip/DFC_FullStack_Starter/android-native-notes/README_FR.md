# DFC Android natif — prochaine partie

La version web/PWA ne peut pas remplacer les API Android natives pour Wi‑Fi Direct ou Bluetooth. Cette partie doit être développée dans un projet Android (Kotlin) avec :

- `WifiP2pManager` et `BroadcastReceiver` pour découvrir les appareils, former un groupe Wi‑Fi Direct et ouvrir une connexion socket entre appareils ;
- permissions Android adaptées à la version (Nearby Wi‑Fi devices / localisation selon version, Bluetooth connect/scan si Bluetooth est utilisé) et demandes de permissions à l'exécution ;
- protocole de messages versionné, identifiants uniques, accusés de réception, file d'attente locale Room et resynchronisation lorsque l'internet revient ;
- découverte sécurisée, vérification d'identité, chiffrement des échanges et protection contre les appareils inconnus ;
- couche de transport abstraite pour basculer entre Internet (API + Socket.IO) et liaison locale (Wi‑Fi Direct/Bluetooth).

Ne pas déclarer la messagerie hors ligne comme sûre ou fonctionnelle avant d'avoir implémenté le protocole, les permissions, la reconnexion et les tests sur au moins deux vrais téléphones Android. Les appels WebRTC par Wi‑Fi Direct nécessitent également un transport/signaling local et des tests audio/vidéo spécifiques.

## Premier socle de code ajouté
`NearbyTransport.kt` contient maintenant un transport socket local de départ : découverte des pairs Wi-Fi Direct, demande de connexion, socket côté propriétaire du groupe, connexion côté client et transport Bluetooth RFCOMM avec un UUID DFC. Les messages sont encadrés par longueur pour éviter de couper les messages au mauvais endroit. Le fichier `AndroidManifest-permissions.xml` liste les permissions à fusionner dans le manifeste Android.

**Ce n'est pas encore une fonction prête à installer.** Il faut créer le projet Android complet, gérer les autorisations à l'exécution, afficher la liste des appareils, intégrer la file locale et la synchronisation, chiffrer/authentifier chaque message, puis compiler et tester sur des téléphones réels. Le code Kotlin n'a pas pu être compilé ici, car aucun SDK Android n'est installé dans cet environnement.
