require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const helmet = require('helmet');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const Database = require('better-sqlite3');
const { Server } = require('socket.io');
const webpush = require('web-push');

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || 'DEV-ONLY-change-this-secret-before-deployment';
if (process.env.NODE_ENV === 'production' && (!process.env.JWT_SECRET || JWT_SECRET.length < 32 || JWT_SECRET.startsWith('DEV-ONLY'))) { throw new Error('Configuration sécurité : définis un JWT_SECRET aléatoire d’au moins 32 caractères en production.'); }
const BASE = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;
const ROOT = __dirname;
fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true });
fs.mkdirSync(path.join(ROOT, 'uploads'), { recursive: true });
const db = new Database(path.join(ROOT, 'data', 'dfc.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, email TEXT UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, display_name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', avatar_url TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'Disponible', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS friendships (
 id INTEGER PRIMARY KEY AUTOINCREMENT, requester_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 addressee_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(requester_id, addressee_id), CHECK(requester_id <> addressee_id)
);
CREATE TABLE IF NOT EXISTS conversations (
 id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', is_group INTEGER NOT NULL DEFAULT 0,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS conversation_members (
 conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(conversation_id,user_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 sender_id TEXT NOT NULL REFERENCES users(id), body TEXT NOT NULL DEFAULT '', media_url TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, edited_at TEXT, deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS messages_conversation_time ON messages(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS posts (
 id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL DEFAULT '', media_url TEXT NOT NULL DEFAULT '', media_type TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS post_likes (
 post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(post_id,user_id)
);
CREATE TABLE IF NOT EXISTS comments (
 id TEXT PRIMARY KEY, post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notifications (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', data_json TEXT NOT NULL DEFAULT '{}',
 read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS push_subscriptions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 endpoint TEXT NOT NULL UNIQUE, subscription_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS call_history (
 id TEXT PRIMARY KEY, caller_id TEXT NOT NULL REFERENCES users(id), callee_id TEXT NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'started', started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ended_at TEXT
);
`);
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
}

const app = express();
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true, credentials: true }));
app.use(express.json({ limit: '2mb' }));
// Limitation simple en mémoire des tentatives d'authentification (compléter par un rate-limit partagé en production).
const authAttempts = new Map();
app.use('/api/auth', (req,res,next)=>{const key=(req.ip||req.socket.remoteAddress||'unknown')+'|'+req.path;const now=Date.now();let item=authAttempts.get(key);if(!item||now-item.start>15*60*1000)item={start:now,count:0};item.count++;authAttempts.set(key,item);if(item.count>30)return res.status(429).json({error:'Trop de tentatives. Réessaie dans quelques minutes.'});next();});
setInterval(()=>{const now=Date.now();for(const [k,v] of authAttempts)if(now-v.start>30*60*1000)authAttempts.delete(k)},10*60*1000).unref();
app.use('/uploads', express.static(path.join(ROOT, 'uploads')));
app.use(express.static(path.join(ROOT, 'public')));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true } });
const upload = multer({ dest: path.join(ROOT, 'uploads'), limits: { fileSize: 30 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
  const ok = /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm)|audio\/(mpeg|ogg|webm|wav))$/.test(file.mimetype);
  cb(ok ? null : new Error('Type de fichier non accepté'), ok);
}});
const id = () => crypto.randomUUID();
const safeUser = row => row && ({ id: row.id, username: row.username, email: row.email, displayName: row.display_name, bio: row.bio, avatarUrl: row.avatar_url, status: row.status, createdAt: row.created_at });
const tokenFor = user => jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: '14d' });
function auth(req, res, next) {
  const raw = req.headers.authorization || '';
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  try { if (!token) throw new Error('missing'); req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Authentification requise.' }); }
}
function member(conversationId, userId) {
  return !!db.prepare('SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?').get(conversationId, userId);
}
function makeNotification(userId, type, title, body, data = {}) {
  const nid = id();
  db.prepare('INSERT INTO notifications(id,user_id,type,title,body,data_json) VALUES(?,?,?,?,?,?)').run(nid,userId,type,title,body,JSON.stringify(data));
  io.to(`user:${userId}`).emit('notification:new', { id:nid,type,title,body,data,createdAt:new Date().toISOString() });
  if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    const subs = db.prepare('SELECT id,subscription_json FROM push_subscriptions WHERE user_id=?').all(userId);
    for (const s of subs) webpush.sendNotification(JSON.parse(s.subscription_json), JSON.stringify({ title, body, data })).catch(err => {
      if (err.statusCode === 404 || err.statusCode === 410) db.prepare('DELETE FROM push_subscriptions WHERE id=?').run(s.id);
    });
  }
  return nid;
}
function apiError(res, err) {
  if (err && err.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ error: 'Cette valeur existe déjà.' });
  console.error(err);
  return res.status(500).json({ error: 'Erreur interne du serveur.' });
}

app.get('/api/health', (req,res)=>res.json({ ok:true, service:'DFC API', time:new Date().toISOString() }));
app.get('/api/config', (req,res)=>res.json({ appName:'DFC — Désiré FreeChat', slogan:'La liberté de communiquer.', webPushReady:!!(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY), vapidPublicKey:process.env.VAPID_PUBLIC_KEY||null, realtime:true, calls:'WebRTC signaling available; STUN/TURN must be configured by client/deployment.' }));
app.post('/api/auth/register', async (req,res)=>{
  try {
    const { username, email='', password, displayName } = req.body || {};
    if (!username || !/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) return res.status(400).json({error:'Identifiant : 3 à 24 caractères (lettres, chiffres, _, . ou -).'});
    if (typeof password !== 'string' || password.length < 8) return res.status(400).json({error:'Le mot de passe doit contenir au moins 8 caractères.'});
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:'Adresse e-mail invalide.'});
    const name = String(displayName || username).trim().slice(0,60);
    const uid = id(); const hash = await bcrypt.hash(password, 12);
    db.prepare('INSERT INTO users(id,username,email,password_hash,display_name) VALUES(?,?,?,?,?)').run(uid,username,email || null,hash,name);
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(uid);
    res.status(201).json({ user:safeUser(user), token:tokenFor(user) });
  } catch(e) { apiError(res,e); }
});
app.post('/api/auth/login', async (req,res)=>{
  try {
    const { login, password } = req.body || {};
    const user = db.prepare('SELECT * FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE').get(String(login||''),String(login||''));
    if (!user || !await bcrypt.compare(String(password||''),user.password_hash)) return res.status(401).json({error:'Identifiant ou mot de passe incorrect.'});
    res.json({ user:safeUser(user), token:tokenFor(user) });
  } catch(e) { apiError(res,e); }
});
app.get('/api/me', auth, (req,res)=>res.json({user:safeUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.sub))}));
app.delete('/api/me', auth, (req,res)=>{const uid=req.user.sub;const tx=db.transaction(()=>{db.prepare('DELETE FROM call_history WHERE caller_id=? OR callee_id=?').run(uid,uid);db.prepare('DELETE FROM messages WHERE sender_id=?').run(uid);db.prepare('DELETE FROM conversation_members WHERE user_id=?').run(uid);db.prepare('DELETE FROM conversations WHERE created_by=?').run(uid);return db.prepare('DELETE FROM users WHERE id=?').run(uid)});const r=tx();for(const s of io.sockets.sockets.values())if(s.user&&s.user.sub===uid)s.disconnect(true);res.json({ok:r.changes>0,message:'Compte et données associées supprimés.'});});
app.patch('/api/me', auth, (req,res)=>{
  const { displayName, bio, avatarUrl, status } = req.body || {};
  db.prepare('UPDATE users SET display_name=?,bio=?,avatar_url=?,status=? WHERE id=?').run(
    String(displayName ?? db.prepare('SELECT display_name FROM users WHERE id=?').get(req.user.sub).display_name).trim().slice(0,60),
    String(bio ?? db.prepare('SELECT bio FROM users WHERE id=?').get(req.user.sub).bio).slice(0,500),
    String(avatarUrl ?? db.prepare('SELECT avatar_url FROM users WHERE id=?').get(req.user.sub).avatar_url).slice(0,500),
    String(status ?? db.prepare('SELECT status FROM users WHERE id=?').get(req.user.sub).status).slice(0,40), req.user.sub);
  res.json({user:safeUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.sub))});
});
app.get('/api/users/search', auth, (req,res)=>{
  const q = `%${String(req.query.q||'').trim().slice(0,40)}%`;
  if (q === '%%') return res.json({users:[]});
  const users = db.prepare(`SELECT * FROM users WHERE id<>? AND (username LIKE ? OR display_name LIKE ?) ORDER BY username LIMIT 30`).all(req.user.sub,q,q).map(safeUser);
  res.json({users});
});
app.post('/api/friends/request', auth, (req,res)=>{
  const target = db.prepare('SELECT id FROM users WHERE username=? COLLATE NOCASE OR id=?').get(String(req.body.username||''),String(req.body.userId||''));
  if (!target) return res.status(404).json({error:'Utilisateur introuvable.'});
  if (target.id === req.user.sub) return res.status(400).json({error:'Tu ne peux pas t’ajouter toi-même.'});
  const existing = db.prepare('SELECT * FROM friendships WHERE (requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?)').get(req.user.sub,target.id,target.id,req.user.sub);
  if (existing) return res.status(409).json({error:'Une demande ou une relation existe déjà.',status:existing.status});
  const result = db.prepare('INSERT INTO friendships(requester_id,addressee_id) VALUES(?,?)').run(req.user.sub,target.id);
  makeNotification(target.id,'friend_request','Nouvelle demande d’ami','Quelqu’un souhaite t’ajouter.',{friendshipId:result.lastInsertRowid,from:req.user.sub});
  res.status(201).json({ok:true,status:'pending'});
});
app.get('/api/friends', auth, (req,res)=>{
 const rows = db.prepare(`SELECT f.*, u1.username AS a_username,u1.display_name AS a_name,u1.avatar_url AS a_avatar,u2.username AS b_username,u2.display_name AS b_name,u2.avatar_url AS b_avatar FROM friendships f JOIN users u1 ON u1.id=f.requester_id JOIN users u2 ON u2.id=f.addressee_id WHERE f.requester_id=? OR f.addressee_id=? ORDER BY f.created_at DESC`).all(req.user.sub,req.user.sub);
 res.json({friends:rows.map(f=>({id:f.id,status:f.status,direction:f.requester_id===req.user.sub?'sent':'received',user:{id:f.requester_id===req.user.sub?f.addressee_id:f.requester_id,username:f.requester_id===req.user.sub?f.b_username:f.a_username,displayName:f.requester_id===req.user.sub?f.b_name:f.a_name,avatarUrl:f.requester_id===req.user.sub?f.b_avatar:f.a_avatar}}))});
});
app.post('/api/friends/:id/accept', auth, (req,res)=>{
 const f=db.prepare('SELECT * FROM friendships WHERE id=? AND addressee_id=? AND status="pending"').get(Number(req.params.id),req.user.sub);
 if(!f)return res.status(404).json({error:'Demande introuvable.'});
 db.prepare('UPDATE friendships SET status="accepted" WHERE id=?').run(f.id);
 makeNotification(f.requester_id,'friend_accepted','Demande acceptée','Votre demande d’ami a été acceptée.',{friendshipId:f.id});
 res.json({ok:true});
});
app.delete('/api/friends/:id', auth, (req,res)=>{const r=db.prepare('DELETE FROM friendships WHERE id=? AND (requester_id=? OR addressee_id=?)').run(Number(req.params.id),req.user.sub,req.user.sub);res.json({ok:r.changes>0});});
app.post('/api/conversations', auth, (req,res)=>{
 const peers=Array.isArray(req.body.memberIds)?[...new Set(req.body.memberIds.map(String))]:[];
 const group=!!req.body.isGroup;
 if(!group && peers.length!==1)return res.status(400).json({error:'Une conversation privée doit avoir exactement un autre membre.'});
 if(peers.length>99)return res.status(400).json({error:'Groupe trop grand.'});
 if(peers.includes(req.user.sub))return res.status(400).json({error:'Ne répète pas ton propre identifiant.'});
 for(const p of peers)if(!db.prepare('SELECT 1 FROM users WHERE id=?').get(p))return res.status(404).json({error:'Un membre est introuvable.'});
 if(!group){const existing=db.prepare(`SELECT c.id FROM conversations c JOIN conversation_members a ON a.conversation_id=c.id JOIN conversation_members b ON b.conversation_id=c.id WHERE c.is_group=0 AND a.user_id=? AND b.user_id=?`).get(req.user.sub,peers[0]);if(existing)return res.json({conversationId:existing.id,existing:true});}
 const cid=id(); const tx=db.transaction(()=>{db.prepare('INSERT INTO conversations(id,title,is_group,created_by) VALUES(?,?,?,?)').run(cid,String(req.body.title||'').slice(0,80),group?1:0,req.user.sub);const ins=db.prepare('INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?)');ins.run(cid,req.user.sub);peers.forEach(p=>ins.run(cid,p));});tx();res.status(201).json({conversationId:cid});
});
app.get('/api/conversations', auth, (req,res)=>{
 const rows=db.prepare(`SELECT c.id,c.title,c.is_group,c.created_at,(SELECT body FROM messages m WHERE m.conversation_id=c.id AND m.deleted_at IS NULL ORDER BY m.created_at DESC LIMIT 1) last_message,(SELECT created_at FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1) last_message_at FROM conversations c JOIN conversation_members cm ON cm.conversation_id=c.id WHERE cm.user_id=? ORDER BY COALESCE(last_message_at,c.created_at) DESC`).all(req.user.sub);
 res.json({conversations:rows});
});
app.get('/api/conversations/:id/messages', auth, (req,res)=>{
 if(!member(req.params.id,req.user.sub))return res.status(403).json({error:'Accès refusé.'});
 const before=String(req.query.before||'9999-12-31 23:59:59'); const messages=db.prepare(`SELECT m.id,m.conversation_id AS conversationId,m.sender_id AS senderId,m.body,m.media_url AS mediaUrl,m.created_at AS createdAt,u.username,u.display_name AS displayName FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=? AND m.deleted_at IS NULL AND m.created_at<? ORDER BY m.created_at DESC LIMIT 100`).all(req.params.id,before).reverse();res.json({messages});
});
app.post('/api/conversations/:id/messages', auth, (req,res)=>{
 if(!member(req.params.id,req.user.sub))return res.status(403).json({error:'Accès refusé.'});
 const body=String(req.body.body||'').trim().slice(0,5000); const mediaUrl=String(req.body.mediaUrl||'').slice(0,500);if(!body&&!mediaUrl)return res.status(400).json({error:'Le message est vide.'});
 const mid=id();db.prepare('INSERT INTO messages(id,conversation_id,sender_id,body,media_url) VALUES(?,?,?,?,?)').run(mid,req.params.id,req.user.sub,body,mediaUrl);
 const m=db.prepare('SELECT m.id,m.conversation_id AS conversationId,m.sender_id AS senderId,m.body,m.media_url AS mediaUrl,m.created_at AS createdAt,u.username,u.display_name AS displayName FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?').get(mid);
 io.to(`conversation:${req.params.id}`).emit('message:new',m);
 db.prepare('SELECT user_id FROM conversation_members WHERE conversation_id=? AND user_id<>?').all(req.params.id,req.user.sub).forEach(x=>makeNotification(x.user_id,'message','Nouveau message',body.slice(0,120)||'Pièce jointe',{conversationId:req.params.id,messageId:mid}));
 res.status(201).json({message:m});
});
app.post('/api/uploads', auth, upload.single('file'), (req,res)=>{if(!req.file)return res.status(400).json({error:'Aucun fichier envoyé.'});const ext=path.extname(req.file.originalname).replace(/[^a-zA-Z0-9.]/g,'').slice(0,10);const name=req.file.filename+ext;fs.renameSync(req.file.path,path.join(ROOT,'uploads',name));res.status(201).json({url:`${BASE}/uploads/${name}`,mimeType:req.file.mimetype,size:req.file.size});});
app.get('/api/posts', auth, (req,res)=>{const posts=db.prepare(`SELECT p.id,p.author_id AS authorId,p.body,p.media_url AS mediaUrl,p.media_type AS mediaType,p.created_at AS createdAt,u.username,u.display_name AS displayName,u.avatar_url AS avatarUrl,(SELECT COUNT(*) FROM post_likes l WHERE l.post_id=p.id) likes,(SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) comments,(SELECT COUNT(*) FROM post_likes l WHERE l.post_id=p.id AND l.user_id=?) likedByMe FROM posts p JOIN users u ON u.id=p.author_id ORDER BY p.created_at DESC LIMIT 100`).all(req.user.sub);res.json({posts});});
app.post('/api/posts', auth, (req,res)=>{const body=String(req.body.body||'').trim().slice(0,3000),mediaUrl=String(req.body.mediaUrl||'').slice(0,500),mediaType=String(req.body.mediaType||'').slice(0,40);if(!body&&!mediaUrl)return res.status(400).json({error:'Publication vide.'});const pid=id();db.prepare('INSERT INTO posts(id,author_id,body,media_url,media_type) VALUES(?,?,?,?,?)').run(pid,req.user.sub,body,mediaUrl,mediaType);res.status(201).json({id:pid});});
app.post('/api/posts/:id/like', auth, (req,res)=>{if(!db.prepare('SELECT 1 FROM posts WHERE id=?').get(req.params.id))return res.status(404).json({error:'Publication introuvable.'});const post=db.prepare('SELECT author_id,body FROM posts WHERE id=?').get(req.params.id);const existing=db.prepare('SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?').get(req.params.id,req.user.sub);if(existing)db.prepare('DELETE FROM post_likes WHERE post_id=? AND user_id=?').run(req.params.id,req.user.sub);else{db.prepare('INSERT INTO post_likes(post_id,user_id) VALUES(?,?)').run(req.params.id,req.user.sub);if(post.author_id!==req.user.sub)makeNotification(post.author_id,'like','Nouvelle mention J’aime','Quelqu’un aime ta publication.',{postId:req.params.id,from:req.user.sub});}res.json({liked:!existing});});
app.delete('/api/posts/:id', auth, (req,res)=>{const r=db.prepare('DELETE FROM posts WHERE id=? AND author_id=?').run(req.params.id,req.user.sub);res.json({ok:r.changes>0});});
app.get('/api/posts/:id/comments', auth, (req,res)=>{const comments=db.prepare('SELECT c.id,c.body,c.created_at AS createdAt,u.id AS userId,u.username,u.display_name AS displayName FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.created_at ASC LIMIT 200').all(req.params.id);res.json({comments});});
app.post('/api/posts/:id/comments', auth, (req,res)=>{const body=String(req.body.body||'').trim().slice(0,1000);if(!body)return res.status(400).json({error:'Commentaire vide.'});if(!db.prepare('SELECT 1 FROM posts WHERE id=?').get(req.params.id))return res.status(404).json({error:'Publication introuvable.'});const cid=id();db.prepare('INSERT INTO comments(id,post_id,user_id,body) VALUES(?,?,?,?)').run(cid,req.params.id,req.user.sub,body);const post=db.prepare('SELECT author_id FROM posts WHERE id=?').get(req.params.id);if(post.author_id!==req.user.sub)makeNotification(post.author_id,'comment','Nouveau commentaire','Quelqu’un a commenté ta publication.',{postId:req.params.id,commentId:cid,from:req.user.sub});res.status(201).json({id:cid});});
app.get('/api/notifications', auth, (req,res)=>{const rows=db.prepare('SELECT id,type,title,body,data_json AS dataJson,read_at AS readAt,created_at AS createdAt FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(req.user.sub).map(n=>({...n,data:JSON.parse(n.dataJson)}));res.json({notifications:rows});});
app.post('/api/notifications/:id/read', auth, (req,res)=>{const r=db.prepare('UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?').run(req.params.id,req.user.sub);res.json({ok:r.changes>0});});
app.post('/api/push/subscribe', auth, (req,res)=>{const sub=req.body.subscription;if(!sub||!sub.endpoint||!sub.keys)return res.status(400).json({error:'Abonnement push invalide.'});db.prepare('INSERT INTO push_subscriptions(user_id,endpoint,subscription_json) VALUES(?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,subscription_json=excluded.subscription_json').run(req.user.sub,sub.endpoint,JSON.stringify(sub));res.status(201).json({ok:true,ready:!!(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY)});});
app.post('/api/calls', auth, (req,res)=>{const callee=String(req.body.calleeId||'');const kind=req.body.kind==='video'?'video':'audio';if(callee===req.user.sub)return res.status(400).json({error:'Tu ne peux pas t’appeler toi-même.'});if(!db.prepare('SELECT 1 FROM users WHERE id=?').get(callee))return res.status(404).json({error:'Utilisateur introuvable.'});const cid=id();db.prepare('INSERT INTO call_history(id,caller_id,callee_id,kind) VALUES(?,?,?,?)').run(cid,req.user.sub,callee,kind);io.to(`user:${callee}`).emit('call:incoming',{callId:cid,callerId:req.user.sub,kind});makeNotification(callee,'call','Appel entrant',`Appel ${kind==='video'?'vidéo':'audio'} entrant`,{callId:cid,callerId:req.user.sub,kind});res.status(201).json({callId:cid,kind,signaling:'ready'});});
app.post('/api/calls/:id/end', auth, (req,res)=>{const r=db.prepare('UPDATE call_history SET status=?,ended_at=CURRENT_TIMESTAMP WHERE id=? AND (caller_id=? OR callee_id=?)').run(String(req.body.status||'ended').slice(0,30),req.params.id,req.user.sub,req.user.sub);res.json({ok:r.changes>0});});
app.get('/api/calls/history', auth, (req,res)=>{const rows=db.prepare(`SELECT c.*,u.username AS peerUsername,u.display_name AS peerDisplayName FROM call_history c JOIN users u ON u.id=CASE WHEN c.caller_id=? THEN c.callee_id ELSE c.caller_id END WHERE c.caller_id=? OR c.callee_id=? ORDER BY c.started_at DESC LIMIT 100`).all(req.user.sub,req.user.sub,req.user.sub);res.json({calls:rows});});
app.get('/api/admin/summary', auth, (req,res)=>res.status(403).json({error:'Une console administrateur avec rôles explicites reste à configurer.'}));
app.get('*', (req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(400).json({error:'Fichier trop volumineux ou invalide.'});if(err)return res.status(400).json({error:err.message||'Requête invalide.'});next();});

io.use((socket,next)=>{try{const token=socket.handshake.auth&&socket.handshake.auth.token;if(!token)throw new Error('missing');socket.user=jwt.verify(token,JWT_SECRET);next();}catch{next(new Error('Authentification requise'));}});
io.on('connection',socket=>{
 const uid=socket.user.sub;socket.join(`user:${uid}`);
 socket.on('conversation:join',cid=>{if(typeof cid==='string'&&member(cid,uid))socket.join(`conversation:${cid}`);});
 socket.on('typing',payload=>{const cid=payload&&payload.conversationId;if(typeof cid==='string'&&member(cid,uid))socket.to(`conversation:${cid}`).emit('typing',{conversationId:cid,userId:uid,typing:!!payload.typing});});
 // WebRTC signaling only: clients must acquire camera/microphone and create RTCPeerConnection.
 socket.on('call:offer',p=>relayCallSignal(socket,uid,p,'offer'));
 socket.on('call:answer',p=>relayCallSignal(socket,uid,p,'answer'));
 socket.on('call:ice',p=>relayCallSignal(socket,uid,p,'ice'));
 socket.on('call:reject',p=>relayCallSignal(socket,uid,p,'reject'));
 socket.on('call:end',p=>relayCallSignal(socket,uid,p,'end'));
});
function relayCallSignal(socket,from,p,event){if(!p||typeof p.callId!=='string'||typeof p.to!=='string')return;const call=db.prepare('SELECT caller_id,callee_id FROM call_history WHERE id=?').get(p.callId);if(!call||![call.caller_id,call.callee_id].includes(from)||![call.caller_id,call.callee_id].includes(p.to)||from===p.to)return;if(event==='reject'||event==='end'){db.prepare('UPDATE call_history SET status=?,ended_at=CURRENT_TIMESTAMP WHERE id=?').run(event==='reject'?'rejected':'ended',p.callId);}io.to(`user:${p.to}`).emit(`call:${event}`,{callId:p.callId,from,to:p.to,...(event==='offer'?{offer:p.offer}:event==='answer'?{answer:p.answer}:event==='ice'?{candidate:p.candidate}:{})});}
server.listen(PORT,()=>console.log(`DFC API prête sur ${BASE} (port ${PORT})`));
